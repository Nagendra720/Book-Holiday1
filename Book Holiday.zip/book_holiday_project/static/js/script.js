document.addEventListener('DOMContentLoaded', function() {
  // Login Form
  const loginForm = document.getElementById('login-form');
  const registerForm = document.getElementById('register-form');
  const messageContainer = document.getElementById('message-container');

  // Sample data for countries, states, and cities
  const countryData = {
    'India': {
      states: {
        'Maharashtra': ['Mumbai', 'Pune', 'Nagpur'],
        'Karnataka': ['Bangalore', 'Mysore', 'Hubli'],
        'Delhi': ['New Delhi']
      }
    },
    'USA': {
      states: {
        'California': ['Los Angeles', 'San Francisco', 'San Diego'],
        'New York': ['New York City', 'Buffalo']
      }
    },
    'UK': {
      states: {
        'England': ['London', 'Manchester'],
        'Scotland': ['Edinburgh', 'Glasgow']
      }
    }
  };

  if (loginForm) {
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');

    loginForm.addEventListener('submit', function(event) {
      event.preventDefault();
      const email = emailInput.value.trim();
      const password = passwordInput.value.trim();

      messageContainer.style.display = 'none';
      messageContainer.className = '';

      if (email === '' || password === '') {
        showMessage('Please fill in all credentials.', 'error');
        return;
      }

      // Submit form via fetch (handled by Django)
      fetch('/login/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'X-CSRFToken': getCookie('csrftoken')
        },
        body: new URLSearchParams({
          'email': email,
          'password': password
        })
      }).then(response => response.json())
        .then(data => {
          if (data.success) {
            showMessage('Login successful!', 'success');
            loginForm.style.display = 'none';
            window.location.href = '/dashboard/';
          } else {
            showMessage(data.error || 'Invalid email or password.', 'error');
          }
        });
    });
  }

  if (registerForm) {
    const firstNameInput = document.getElementById('first_name');
    const lastNameInput = document.getElementById('last_name');
    const genderSelect = document.getElementById('gender');
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    const confirmPasswordInput = document.getElementById('confirm_password');
    const ageInput = document.getElementById('age');
    const countryCodeSelect = document.getElementById('country_code');
    const mobileInput = document.getElementById('mobile');
    const hobbiesSelect = document.getElementById('hobbies');
    const countrySelect = document.getElementById('country');
    const stateSelect = document.getElementById('state');
    const citySelect = document.getElementById('city');
    const zipCodeInput = document.getElementById('zip_code');

    // Populate countries
    Object.keys(countryData).forEach(country => {
      const option = document.createElement('option');
      option.value = country;
      option.textContent = country;
      countrySelect.appendChild(option);
    });

    // Handle country change
    countrySelect.addEventListener('change', function() {
      stateSelect.innerHTML = '<option value="" disabled selected>Select State</option>';
      citySelect.innerHTML = '<option value="" disabled selected>Select City</option>';
      stateSelect.disabled = true;
      citySelect.disabled = true;

      const selectedCountry = this.value;
      if (selectedCountry && countryData[selectedCountry]) {
        stateSelect.disabled = false;
        Object.keys(countryData[selectedCountry].states).forEach(state => {
          const option = document.createElement('option');
          option.value = state;
          option.textContent = state;
          stateSelect.appendChild(option);
        });
      }
    });

    // Handle state change
    stateSelect.addEventListener('change', function() {
      citySelect.innerHTML = '<option value="" disabled selected>Select City</option>';
      citySelect.disabled = true;

      const selectedCountry = countrySelect.value;
      const selectedState = this.value;
      if (selectedCountry && selectedState && countryData[selectedCountry].states[selectedState]) {
        citySelect.disabled = false;
        countryData[selectedCountry].states[selectedState].forEach(city => {
          const option = document.createElement('option');
          option.value = city;
          option.textContent = city;
          citySelect.appendChild(option);
        });
      }
    });

    registerForm.addEventListener('submit', function(event) {
      event.preventDefault();
      messageContainer.style.display = 'none';
      messageContainer.className = '';

      const firstName = firstNameInput.value.trim();
      const lastName = lastNameInput.value.trim();
      const gender = genderSelect.value;
      const email = emailInput.value.trim();
      const password = passwordInput.value;
      const confirmPassword = confirmPasswordInput.value;
      const age = parseInt(ageInput.value);
      const mobile = mobileInput.value.trim();
      const hobbies = Array.from(hobbiesSelect.selectedOptions).map(opt => opt.value);
      const country = countrySelect.value;
      const state = stateSelect.value;
      const city = citySelect.value;
      const zipCode = zipCodeInput.value.trim();

      // Client-side validation
      if (!firstName || !/^[a-zA-Z\s]{1,30}$/.test(firstName)) {
        showMessage('First name must be letters only and up to 30 characters.', 'error');
        return;
      }
      if (!lastName || !/^[a-zA-Z\s]{1,30}$/.test(lastName)) {
        showMessage('Last name must be letters only and up to 30 characters.', 'error');
        return;
      }
      if (!gender) {
        showMessage('Please select a gender.', 'error');
        return;
      }
      if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        showMessage('Please enter a valid email address.', 'error');
        return;
      }
      if (!password || password.length < 6) {
        showMessage('Password must be at least 6 characters.', 'error');
        return;
      }
      if (password !== confirmPassword) {
        showMessage('Passwords do not match.', 'error');
        return;
      }
      if (!age || age < 1 || age > 120) {
        showMessage('Please enter a valid age between 1 and 120.', 'error');
        return;
      }
      if (!mobile || !/^\d{10}$/.test(mobile)) {
        showMessage('Mobile number must be 10 digits.', 'error');
        return;
      }
      if (hobbies.length === 0) {
        showMessage('Please select at least one hobby.', 'error');
        return;
      }
      if (!country) {
        showMessage('Please select a country.', 'error');
        return;
      }
      if (!state) {
        showMessage('Please select a state.', 'error');
        return;
      }
      if (!city) {
        showMessage('Please select a city.', 'error');
        return;
      }
      if (!zipCode || !/^\d{6}$/.test(zipCode)) {
        showMessage('Zip code must be exactly 6 digits.', 'error');
        return;
      }

      // Submit form via fetch
      fetch('/register/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'X-CSRFToken': getCookie('csrftoken')
        },
        body: new URLSearchParams({
          'first_name': firstName,
          'last_name': lastName,
          'gender': gender,
          'email': email,
          'password': password,
          'age': age,
          'country_code': countryCodeSelect.value,
          'mobile': mobile,
          'hobbies': hobbies.join(','),
          'country': country,
          'state': state,
          'city': city,
          'zip_code': zipCode
        })
      }).then(response => response.json())
        .then(data => {
          if (data.success) {
            showMessage('Registration successful!', 'success');
            registerForm.style.display = 'none';
            setTimeout(() => { window.location.href = '/dashboard/'; }, 1000);
          } else {
            showMessage(data.error || 'Registration failed.', 'error');
          }
        });
    });
  }

  function showMessage(message, type) {
    messageContainer.textContent = message;
    messageContainer.className = type === 'success' ? 'message-success' : 'message-error';
    messageContainer.style.display = 'block';
  }

  function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
      const cookies = document.cookie.split(';');
      for (let i = 0; i < cookies.length; i++) {
        const cookie = cookies[i].trim();
        if (cookie.substring(0, name.length + 1) === (name + '=')) {
          cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
          break;
        }
      }
    }
    return cookieValue;
  }
});