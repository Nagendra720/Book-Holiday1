# book_holiday_project/book_holiday_project/urls.py

from django.contrib import admin
from django.urls import path, include  # Make sure to import 'include'

urlpatterns = [
    path('admin/', admin.site.urls),
    # This tells the main project to look at the urls.py file in the 'accounts' app
    path('', include('accounts.urls')), 
]