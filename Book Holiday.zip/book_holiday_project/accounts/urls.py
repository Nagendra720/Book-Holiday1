#//accounts//urls.py
# book_holiday_project/accounts/urls.py

from django.urls import path
from . import views

urlpatterns = [
    path('', views.login_view, name='login'),
    path('register/', views.register_view, name='register'), # Add register URL
    path('dashboard/', views.dashboard_view, name='dashboard'), 
    path('logout/', views.logout_view, name='logout'),

    # AJAX URLS
    path('ajax/load-states/', views.load_states, name='ajax_load_states'),
    path('ajax/load-cities/', views.load_cities, name='ajax_load_cities'),
]