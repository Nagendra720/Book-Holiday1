#//accounts//views.py
# book_holiday_project/accounts/views.py

from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.http import JsonResponse
from .forms import RegistrationForm # Import the new form

# Mock data for dependent dropdowns. In a real application, this might come from a database.
LOCATION_DATA = {
    "IN": { # India
        "Maharashtraa": ["Mumbai", "Pune", "Nagpur"],
        "Delhi": ["New Delhi"],
        "Karnataka": ["Bengaluru", "Mysuru"],
        "Odisha": ["Bhubaneswar", "Berhampur"]
    },
    "US": { # USA
        "California": ["Los Angeles", "San Francisco", "San Diego"],
        "New York": ["New York City", "Buffalo", "Rochester"],
        "Texas": ["Houston", "Austin", "Dallas"]
    }
}


def login_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
        
    context = {}
    if request.method == 'POST':
        # In a real Django app, the username is often the email.
        # We need to get the user object by email to use it with authenticate.
        try:
            user_obj = User.objects.get(email=request.POST.get('email'))
            username = user_obj.username
        except User.DoesNotExist:
            username = None # User does not exist

        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('dashboard')
        else:
            context['error'] = 'Invalid credentials. Please try again.'
    
    return render(request, 'login.html', context)


def register_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
        
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            # Create the user
            user = User.objects.create_user(
                # Django's User model requires a unique username. We'll use the email.
                username=form.cleaned_data['email'], 
                email=form.cleaned_data['email'],
                password=form.cleaned_data['password'],
                first_name=form.cleaned_data['first_name'],
                last_name=form.cleaned_data['last_name']
            )
            # You can save the extra profile data to a different model if you have one.
            # For now, we'll just create the user.
            
            # You can add a success message here using Django's messages framework
            # messages.success(request, 'Registration successful! Please log in.')
            return redirect('login')
    else:
        form = RegistrationForm()
        
    return render(request, 'register.html', {'form': form})


@login_required
def dashboard_view(request):
    return render(request, 'dashboard.html')

def logout_view(request):
    logout(request)
    return redirect('login')

# --- AJAX Views for Dependent Dropdowns ---

def load_states(request):
    country_code = request.GET.get('country')
    states = LOCATION_DATA.get(country_code, {}).keys()
    return JsonResponse(list(states), safe=False)

def load_cities(request):
    country_code = request.GET.get('country')
    state_name = request.GET.get('state')
    cities = LOCATION_DATA.get(country_code, {}).get(state_name, [])
    return JsonResponse(list(cities), safe=False)